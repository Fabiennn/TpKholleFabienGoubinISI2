<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    {!! Html::style('lib/bootstrap/bootstrap.css') !!}

    <title>@yield('titrePage')</title>
</head>
<body class = "p-3 mb-2 bg-primary text-black">
<header>
    <ul class="nav justify-content-center">
        <li class="nav-item">
            <a class="nav-link active text-white-50 bg-dark font-weight-bold text-uppercase" href="#">Filmothéque</a>
        </li>
    </ul>
    <h1>@yield('titreItem')</h1>
</header>
@yield('contenu')

<footer class="footer text-center">
    <p>MangaWeb - copyright 3AInfo - 2020</p>
</footer>
{!! Html::script('lib/jquery/jquery-3.5.1.js') !!}
{!! Html::script('lib/js/bootstrap.bundle.js') !!}
{!! Html::script('lib/js/bootstrap.js/bootstrap.js') !!}
</body>
</html>
