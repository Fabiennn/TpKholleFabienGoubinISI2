<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <?php echo Html::style('lib/bootstrap/bootstrap.css'); ?>


    <title><?php echo $__env->yieldContent('titrePage'); ?></title>
</head>
<body class = "p-3 mb-2 bg-primary text-black">
<header>
    <ul class="nav justify-content-center">
        <li class="nav-item">
            <a class="nav-link active text-white-50 bg-dark font-weight-bold text-uppercase" href="#">Filmothéque</a>
        </li>
    </ul>
    <h1><?php echo $__env->yieldContent('titreItem'); ?></h1>
</header>
<?php echo $__env->yieldContent('contenu'); ?>

<footer class="footer text-center">
    <p>MangaWeb - copyright 3AInfo - 2020</p>
</footer>
<?php echo Html::script('lib/jquery/jquery-3.5.1.js'); ?>

<?php echo Html::script('lib/js/bootstrap.bundle.js'); ?>

<?php echo Html::script('lib/js/bootstrap.js/bootstrap.js'); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\Fabien\TpKholleFabienGoubin\resources\views/template.blade.php ENDPATH**/ ?>