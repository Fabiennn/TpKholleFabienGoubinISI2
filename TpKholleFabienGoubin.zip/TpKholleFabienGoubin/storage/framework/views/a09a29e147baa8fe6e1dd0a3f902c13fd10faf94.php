<?php $__env->startSection('titrePage'); ?>
    Information sur le Manga
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenu'); ?>

    <div class="container-fluid">
    <div class="row">
        <div class="col-12 mt-3">
            <div class="card">
                <div class="card-horizontal">
                    <div class="card-body">
                        <h5 class="card-title">Titre : <?php echo e($film->titre); ?></h5>
                        <p class="card-text">
                        <p>Année de sortie : <?php echo e($film->anneeSortie); ?></p>
                        <p>Catégories : <?php echo e(($categorie->libelle)); ?></p>
                        <p>Description : <?php echo e($film->description); ?></p>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Fabien\TpKholleFabienGoubin\resources\views/afficherFilm.blade.php ENDPATH**/ ?>